NEXA — site web + espace membre + console de traitement des demandes

Fichiers :
- index.html : site responsive, authentification Supabase, espace membre et console admin.
- finance-migration.sql : table des demandes, règles RLS et contrôle serveur par trigger.

Fonctionnement :
- Le membre peut enregistrer une demande de dépôt ou de retrait et suivre son statut.
- L'administrateur authentifié avec app_metadata.role = admin voit les demandes de retrait.
- Après avoir effectué un transfert réel via un prestataire autorisé, l'administrateur peut cliquer sur « Confirmer le paiement » et saisir la référence de transaction.
- Le site enregistre la confirmation, l'identité de l'administrateur et l'heure. Le bouton ne transfère pas d'argent.
- Le bouton ne calcule pas et ne crédite pas de revenus quotidiens liés aux robots.

MISE EN LIGNE :
1. Décompresser le ZIP.
2. Ouvrir le dépôt GitHub nexaccount/Nexa-demo.
3. Ajouter/remplacer index.html à la racine du dépôt, puis valider (Commit changes).
4. Dans GitHub > Settings > Pages, choisir Deploy from a branch, branche main, dossier /(root), puis Save.
5. Attendre la fin du déploiement dans Actions. Ouvrir https://nexaccount.github.io/Nexa-demo/ et actualiser.

CONFIGURATION SUPABASE :
1. Ouvrir Supabase > SQL Editor > New query.
2. Coller le contenu de finance-migration.sql et cliquer Run.
3. Configurer le rôle admin dans app_metadata côté serveur uniquement. Ne pas modifier user_metadata pour cela et ne jamais exposer la clé service_role dans le HTML.
4. Se connecter avec le compte admin : il sera dirigé vers la console d'administration. Les comptes standards restent dans l'espace membre.
5. Tester d'abord avec des comptes et demandes fictifs. Vérifier les politiques RLS avec un compte membre et un compte admin distincts.

IMPORTANT :
- Aucun dépôt ou retrait réel n'est collecté ou transféré par cette maquette.
- Ne pas utiliser un numéro Mobile Money personnel pour encaisser des clients. Les paiements réels exigent un prestataire autorisé, des webhooks signés, un rapprochement comptable et une revue juridique/comptable.
- Ne pas promettre de rendements garantis ni utiliser les dépôts des nouveaux membres pour payer les anciens. Les versements éventuels doivent provenir de recettes commerciales réelles, documentées, disponibles et juridiquement autorisées.
