-- NEXA — registre des demandes financières et validation administrative
-- Ce schéma n'exécute aucun transfert et ne calcule aucun rendement.
create table if not exists public.finance_requests (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  request_type text not null check (request_type in ('deposit', 'withdrawal')),
  amount_xof integer not null check (amount_xof between 1 and 100000000),
  note text not null default '' check (char_length(note) <= 500),
  status text not null default 'pending' check (status in ('pending','under_review','approved','rejected','paid','cancelled')),
  admin_note text not null default '' check (char_length(admin_note) <= 500),
  transaction_reference text not null default '' check (char_length(transaction_reference) <= 160),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  paid_at timestamptz,
  paid_by uuid references auth.users(id)
);
create index if not exists finance_requests_user_created_idx on public.finance_requests(user_id, created_at desc);
create index if not exists finance_requests_status_created_idx on public.finance_requests(status, created_at desc);
alter table public.finance_requests enable row level security;
revoke all on public.finance_requests from anon;
grant select, insert on public.finance_requests to authenticated;
grant update (status, admin_note, transaction_reference, updated_at, paid_at, paid_by) on public.finance_requests to authenticated;
drop policy if exists "members_read_own_finance_requests" on public.finance_requests;
create policy "members_read_own_finance_requests" on public.finance_requests for select to authenticated using (user_id = auth.uid());
drop policy if exists "members_create_pending_finance_requests" on public.finance_requests;
create policy "members_create_pending_finance_requests" on public.finance_requests for insert to authenticated with check (user_id = auth.uid() and status = 'pending' and admin_note = '' and transaction_reference = '');
drop policy if exists "admins_read_all_finance_requests" on public.finance_requests;
create policy "admins_read_all_finance_requests" on public.finance_requests for select to authenticated using ((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin');
drop policy if exists "admins_update_finance_requests" on public.finance_requests;
create policy "admins_update_finance_requests" on public.finance_requests for update to authenticated using ((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin') with check ((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin');
-- Interdit de marquer payé sans référence et enregistre l'identité admin.
create or replace function public.nexa_guard_finance_update() returns trigger language plpgsql security definer set search_path = public as $$
begin
  if (auth.jwt() -> 'app_metadata' ->> 'role') <> 'admin' then
    raise exception 'Admin role required';
  end if;
  if new.status = 'paid' then
    if coalesce(trim(new.transaction_reference), '') = '' then
      raise exception 'Transaction reference required';
    end if;
    if old.status = 'paid' then
      raise exception 'Request already marked paid';
    end if;
    new.paid_at = now();
    new.paid_by = auth.uid();
  end if;
  new.updated_at = now();
  return new;
end; $$;
drop trigger if exists nexa_guard_finance_update on public.finance_requests;
create trigger nexa_guard_finance_update before update on public.finance_requests for each row execute function public.nexa_guard_finance_update();
-- Ne jamais accorder le rôle admin via user_metadata. Le rôle doit être défini côté serveur dans app_metadata.
